CREATE CATALOG IF NOT EXISTS retail_demo;

CREATE SCHEMA IF NOT EXISTS retail_demo.raw;
CREATE SCHEMA IF NOT EXISTS retail_demo.silver;
CREATE SCHEMA IF NOT EXISTS retail_demo.gold;
CREATE SCHEMA IF NOT EXISTS retail_demo.dq;

-- Dimensions

CREATE OR REPLACE TABLE retail_demo.silver.dim_date AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/date_dim`;

CREATE OR REPLACE TABLE retail_demo.silver.dim_time AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/time_dim`;

CREATE OR REPLACE TABLE retail_demo.silver.dim_store AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/stores`;

CREATE OR REPLACE TABLE retail_demo.silver.dim_asset AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/assets`;

CREATE OR REPLACE TABLE retail_demo.silver.dim_device AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/devices`;

CREATE OR REPLACE TABLE retail_demo.silver.dim_product AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/products`;

CREATE OR REPLACE TABLE retail_demo.silver.dim_department AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/departments`;

-- Firmware is a conformed mini-dimension.
CREATE OR REPLACE TABLE retail_demo.silver.dim_firmware AS
SELECT DISTINCT
  firmware_version,
  CASE
    WHEN firmware_version IN ('v3.1','v3.2') THEN 'Legacy'
    WHEN firmware_version='v4.0' THEN 'Current'
    ELSE 'Latest'
  END AS firmware_generation
FROM retail_demo.silver.dim_device;

-- Facts

CREATE OR REPLACE TABLE retail_demo.silver.fact_sales AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/sales`;

CREATE OR REPLACE TABLE retail_demo.silver.fact_inventory_snapshot AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/inventory_snapshot`;

CREATE OR REPLACE TABLE retail_demo.silver.fact_store_traffic AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/store_traffic`;

CREATE OR REPLACE TABLE retail_demo.silver.fact_energy AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/energy`;

CREATE OR REPLACE TABLE retail_demo.silver.fact_telemetry AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/telemetry`;

CREATE OR REPLACE TABLE retail_demo.silver.fact_maintenance AS
SELECT * FROM parquet.`/Volumes/retail_demo/raw/raw_files_v2/maintenance`;
