# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC # DQ Lakeflow Pipeline — Silver Layer
# MAGIC
# MAGIC Lakeflow Spark Declarative Pipeline that enforces data quality expectations on telemetry data. DQ rules are loaded from an external YAML config file (`config/dq_rules.yml`) via the pipeline configuration parameter `dq_rules_path`.

# COMMAND ----------

# DBTITLE 1,DQ Pipeline — Load rules from YAML and enforce expectations
# Example Lakeflow Declarative Pipeline.
# Validate syntax against the target Databricks Runtime before deployment.
#
# The key idea is to enforce deterministic telemetry rules at the pipeline layer
# and retain a governed quality dataset for downstream investigation.
#
# This notebook is a Lakeflow Spark Declarative Pipeline source — it must be
# executed as part of a pipeline (via DABs or the Databricks UI), not as a
# standalone script.

try:
    import dlt
except ImportError:
    raise ImportError(
        "This notebook is a Lakeflow Spark Declarative Pipeline source and requires "
        "the 'dlt' module, which is only available in the pipeline runtime. "
        "Deploy it via the DABs configuration (databricks.yml) or run the "
        "pipeline from the Databricks UI."
    )

# DQ rules are loaded from an external YAML config file.
# The path is passed via pipeline configuration (see databricks.yml →
# pipelines.telemetry_dq_pipeline.configuration.dq_rules_path).
import yaml

dq_rules_path = spark.conf.get("dq_rules_path")
with open(dq_rules_path, "r") as f:
    rules = yaml.safe_load(f)

telemetry_schema = "event_id string, device_id string, asset_id string, store_id string, sensor_type string, firmware_version string, event_time timestamp, ingestion_time timestamp, value double, unit string"

@dlt.table(name="silver_telemetry_quality_controlled")
@dlt.expect_all(rules)
def silver_telemetry_quality_controlled():
    return spark.readStream.format("parquet").schema(telemetry_schema).load("/Volumes/retail_demo/raw/raw_files_v2/telemetry")