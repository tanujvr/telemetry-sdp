# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC # Generate Synthetic Business Data
# MAGIC
# MAGIC Self-contained data generation for NorthStar Markets: stores, products, departments, time dims, traffic, energy, inventory, sales, assets, sensors, maintenance, and telemetry. Writes parquet to `/Volumes/retail_demo/raw/raw_files_v2/`.

# COMMAND ----------

# DBTITLE 1,Generate business + IoT data
# Generates synthetic business facts for NorthStar Markets.
# Self-contained: generates stores and products inline (no V1 dependency).

from pyspark.sql import functions as F
from datetime import datetime, timedelta
import random

PROFILE = "demo"       # demo | scale
# Create volume if it does not exist
sql("CREATE VOLUME IF NOT EXISTS retail_demo.raw.raw_files_v2")
OUT = "/Volumes/retail_demo/RAW/raw_files_v2"

C = {
    "demo": {"stores":100, "products":2500, "days":7, "assets":10000, "sensors":5000, "telemetry_minutes":5},
    "scale": {"stores":500, "products":10000, "days":14, "assets":75000, "sensors":30000, "telemetry_minutes":5}
}[PROFILE]

random.seed(123)

# -------------------------
# Reference data (self-contained, no V1 dependency)
# -------------------------
states = [
    ("CA","California"),("TX","Texas"),("FL","Florida"),("NY","New York"),
    ("PA","Pennsylvania"),("IL","Illinois"),("OH","Ohio"),("GA","Georgia"),
    ("NC","North Carolina"),("MI","Michigan"),("NJ","New Jersey"),
    ("VA","Virginia"),("WA","Washington"),("AZ","Arizona"),("MA","Massachusetts")
]
store_types = ["Supermarket", "Supercenter", "Multi-Department"]
regions = ["Northeast","Southeast","Midwest","Southwest","West"]
product_departments = ["Grocery","Produce","Meat","Seafood","Dairy","Frozen",
                "Bakery","Deli","Health & Beauty","Household","Electronics",
                "Apparel","Home","Seasonal"]

# -------------------------
# Stores dimension (previously read from V1)
# -------------------------
store_rows = []
for i in range(1, C["stores"] + 1):
    st, state_name = random.choice(states)
    store_rows.append((
        f"S{i:04d}", f"NorthStar Store {i:04d}",
        random.choice(store_types), random.choice(regions),
        st, state_name,
        random.choice(["Urban","Suburban","Rural"]),
        random.randint(25000, 120000),
        random.choice(["Open","Open","Open","Remodeling"])
    ))

stores = spark.createDataFrame(store_rows,
    "store_id string, store_name string, store_type string, region string, "
    "state_code string, state_name string, market_type string, "
    "sqft int, store_status string"
)
stores.write.mode("overwrite").format("parquet").save(f"{OUT}/stores")

# -------------------------
# Products dimension (previously read from V1)
# -------------------------
product_rows = []
for i in range(1, C["products"] + 1):
    dept = random.choice(product_departments)
    product_rows.append((
        f"P{i:06d}", f"{dept} Product {i:06d}", dept,
        random.choice(["Perishable","Non-Perishable"]),
        round(random.uniform(1.99, 249.99), 2)
    ))

products = spark.createDataFrame(product_rows,
    "product_id string, product_name string, department string, "
    "product_class string, unit_price double"
)
products.write.mode("overwrite").format("parquet").save(f"{OUT}/products")

# -------------------------
# Department dimension
# -------------------------
departments = [
    ("D01","Grocery","Food","Core"),
    ("D02","Produce","Food","Perishable"),
    ("D03","Meat","Food","Perishable"),
    ("D04","Seafood","Food","Perishable"),
    ("D05","Dairy","Food","Perishable"),
    ("D06","Frozen","Food","Perishable"),
    ("D07","Bakery","Food","Perishable"),
    ("D08","Deli","Food","Perishable"),
    ("D09","Health & Beauty","GM","Non-Perishable"),
    ("D10","Household","GM","Non-Perishable"),
    ("D11","Electronics","GM","Non-Perishable"),
    ("D12","Apparel","GM","Non-Perishable"),
    ("D13","Home","GM","Non-Perishable"),
    ("D14","Seasonal","GM","Variable")
]

dept = spark.createDataFrame(
    departments,
    "department_id string, department_name string, division string, perishability_class string"
)
dept.write.mode("overwrite").format("parquet").save(f"{OUT}/departments")

# -------------------------
# Enrich products
# -------------------------

products_v2 = (
    products
    .withColumn("department_id",
        F.when(F.col("department")=="Grocery","D01")
         .when(F.col("department")=="Produce","D02")
         .when(F.col("department")=="Meat","D03")
         .when(F.col("department")=="Seafood","D04")
         .when(F.col("department")=="Dairy","D05")
         .when(F.col("department")=="Frozen","D06")
         .when(F.col("department")=="Bakery","D07")
         .when(F.col("department")=="Deli","D08")
         .when(F.col("department")=="Health & Beauty","D09")
         .when(F.col("department")=="Household","D10")
         .when(F.col("department")=="Electronics","D11")
         .when(F.col("department")=="Apparel","D12")
         .when(F.col("department")=="Home","D13")
         .otherwise("D14")
    )
    .withColumn("supplier_id", F.format_string("SUP%03d",(F.rand(44)*80+1).cast("int")))
    .withColumn("case_pack", (F.rand(45)*24+1).cast("int"))
    .withColumn("margin_pct", F.round(F.rand(46)*0.35+0.10,3))
)
products_v2.write.mode("overwrite").format("parquet").save(f"{OUT}/products")

# -------------------------
# Time dimensions
# -------------------------
start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=7)
days = C["days"]

date_rows = []
for d in range(days):
    dt = start + timedelta(days=d)
    date_rows.append((
        dt.date(), dt.year, dt.month, dt.day,
        dt.strftime("%A"), dt.weekday() >= 5,
        dt.strftime("%Y-%m")
    ))

date_dim = spark.createDataFrame(
    date_rows,
    "date date, year int, month int, day int, day_name string, is_weekend boolean, year_month string"
)
date_dim.write.mode("overwrite").format("parquet").save(f"{OUT}/date_dim")

time_rows = []
for h in range(24):
    for m in [0,15,30,45]:
        t = f"{h:02d}:{m:02d}:00"
        time_rows.append((h,m,t,"Overnight" if h<6 else "Morning" if h<11 else "Midday" if h<15 else "Afternoon" if h<18 else "Evening"))
time_dim = spark.createDataFrame(time_rows, "hour int, minute int, time_string string, daypart string")
time_dim.write.mode("overwrite").format("parquet").save(f"{OUT}/time_dim")

# -------------------------
# Hourly store traffic
# -------------------------
hours = spark.range(days*24).select(
    (F.lit(start).cast("timestamp") + F.expr("INTERVAL 1 HOUR") * F.col("id")).alias("hour_ts")
)

traffic = (
    stores.crossJoin(hours)
    .withColumn("hour_of_day", F.hour("hour_ts"))
    .withColumn("dow", F.dayofweek("hour_ts"))
    .withColumn("base_traffic",
        F.when(F.col("hour_of_day").between(7,9), 80)
         .when(F.col("hour_of_day").between(10,15), 140)
         .when(F.col("hour_of_day").between(16,19), 220)
         .when(F.col("hour_of_day").between(20,21), 150)
         .otherwise(25)
    )
    .withColumn("traffic_count",
        F.greatest(F.lit(0),
            (F.col("base_traffic") * (0.85 + F.rand(51)*0.45) *
             F.when(F.col("dow").isin(1,7),1.12).otherwise(1.0)).cast("int")
        )
    )
    .withColumn("peak_queue_minutes",
        F.round(F.greatest(F.lit(0), F.col("traffic_count")/45 + F.rand(52)*4 - 1),1)
    )
    .withColumn("checkout_txn_count",
        (F.col("traffic_count") * (0.58 + F.rand(53)*0.15)).cast("int")
    )
    .select("store_id","hour_ts","traffic_count","peak_queue_minutes","checkout_txn_count")
)
traffic.write.mode("overwrite").format("parquet").save(f"{OUT}/store_traffic")

# -------------------------
# Hourly energy
# -------------------------
energy = (
    stores.crossJoin(hours)
    .withColumn("hour_of_day", F.hour("hour_ts"))
    .withColumn("base_kw",
        F.lit(180) +
        F.when(F.col("hour_of_day").between(10,20),35).otherwise(0) +
        F.rand(61)*60
    )
    .withColumn("hvac_kw", F.round(F.lit(35) + F.rand(62)*45,2))
    .withColumn("refrigeration_kw", F.round(F.lit(70) + F.rand(63)*35,2))
    .withColumn("lighting_kw", F.round(F.lit(20) + F.rand(64)*15,2))
    .withColumn("total_kw", F.round(F.col("hvac_kw")+F.col("refrigeration_kw")+F.col("lighting_kw")+F.rand(65)*20,2))
    .withColumn("energy_kwh", F.col("total_kw"))
    .select("store_id","hour_ts","hvac_kw","refrigeration_kw","lighting_kw","total_kw","energy_kwh")
)

# Inject a realistic energy anomaly for selected stores during business hours.
energy = energy.withColumn(
    "total_kw",
    F.when(
        (F.col("store_id").isin("S0018","S0042","S0077")) &
        (F.hour("hour_ts").between(10,19)) &
        (F.to_date("hour_ts") == F.lit((start + timedelta(days=5)).strftime("%Y-%m-%d"))),
        F.col("total_kw") * 1.55
    ).otherwise(F.col("total_kw"))
).withColumn(
    "energy_anomaly_flag",
    F.when(
        (F.col("store_id").isin("S0018","S0042","S0077")) &
        (F.to_date("hour_ts") == F.lit((start + timedelta(days=5)).strftime("%Y-%m-%d"))), True
    ).otherwise(False)
)

energy.write.mode("overwrite").format("parquet").save(f"{OUT}/energy")

# -------------------------
# Daily inventory snapshots
# -------------------------
dates = spark.range(days).select(
    (F.lit(start).cast("date") + F.col("id").cast("int")).alias("snapshot_date")
)

# Use a representative product population for demo speed.
p = products_v2.select("product_id","department_id","unit_price","product_class","margin_pct").limit(C["products"])

inventory = (
    stores.crossJoin(p).crossJoin(dates)
    .withColumn("on_hand_units", F.greatest(F.lit(0),(F.rand(71)*140).cast("int")))
    .withColumn("on_order_units", (F.rand(72)*50).cast("int"))
    .withColumn("safety_stock_units", (F.rand(73)*35+5).cast("int"))
    .withColumn("units_sold_est", (F.rand(74)*40).cast("int"))
    .withColumn("inventory_value", F.round(F.col("on_hand_units")*F.col("unit_price"),2))
    .withColumn(
        "oos_flag",
        F.when(F.col("on_hand_units") <= 2, True).otherwise(False)
    )
    .withColumn(
        "perishable_exposure_flag",
        (F.col("product_class")=="Perishable") & (F.col("on_hand_units")>20)
    )
)

inventory.write.mode("overwrite").format("parquet").save(f"{OUT}/inventory_snapshot")

# -------------------------
# Hourly sales
# -------------------------
sales = (
    stores.crossJoin(p.limit(min(C["products"],1000))).crossJoin(hours)
    .withColumn("hour_of_day",F.hour("hour_ts"))
    .withColumn(
        "units_sold",
        F.greatest(
            F.lit(0),
            (F.rand(81)*8 *
             F.when(F.col("hour_of_day").between(10,20),2.2).otherwise(0.4)
            ).cast("int")
        )
    )
    .withColumn("gross_sales", F.round(F.col("units_sold")*F.col("unit_price"),2))
    .withColumn("discount_amount", F.round(F.col("gross_sales")*F.rand(82)*0.12,2))
    .withColumn("net_sales", F.round(F.col("gross_sales")-F.col("discount_amount"),2))
    .withColumn("gross_margin", F.round(F.col("net_sales")*F.col("margin_pct"),2))
    .withColumn("transaction_count", F.greatest(F.lit(0),(F.col("units_sold")/2).cast("int")))
    .select("store_id","product_id","hour_ts","units_sold","gross_sales",
            "discount_amount","net_sales","gross_margin","transaction_count")
)

sales.write.mode("overwrite").format("parquet").save(f"{OUT}/sales")

# -------------------------
# Assets dimension (IoT/telemetry)
# -------------------------
asset_types = [
    ("REFRIGERATION","Walk-in Cooler"),
    ("REFRIGERATION","Walk-in Freezer"),
    ("REFRIGERATION","Refrigerated Case"),
    ("REFRIGERATION","Frozen Case"),
    ("HVAC","Rooftop HVAC"),
    ("HVAC","Air Handler"),
    ("ENERGY","Smart Meter"),
    ("CHECKOUT","POS Terminal"),
    ("CHECKOUT","Self Checkout"),
    ("CHECKOUT","Payment Terminal"),
    ("INVENTORY","Smart Shelf"),
    ("INVENTORY","RFID Reader"),
    ("STORE_TECH","Digital Signage"),
    ("STORE_TECH","Network Gateway"),
]

asset_sensor_types = {
    "Walk-in Cooler": ["temperature","humidity","compressor_state"],
    "Walk-in Freezer": ["temperature","humidity","compressor_state"],
    "Refrigerated Case": ["temperature","humidity","door_open"],
    "Frozen Case": ["temperature","humidity","door_open"],
    "Rooftop HVAC": ["temperature","power_kw","fan_speed"],
    "Air Handler": ["temperature","humidity","fan_speed"],
    "Smart Meter": ["power_kw","voltage"],
    "POS Terminal": ["latency_ms","error_rate","availability"],
    "Self Checkout": ["latency_ms","error_rate","availability"],
    "Payment Terminal": ["latency_ms","error_rate","availability"],
    "Smart Shelf": ["stock_level","weight_kg","availability"],
    "RFID Reader": ["read_rate","availability"],
    "Digital Signage": ["availability","latency_ms"],
    "Network Gateway": ["latency_ms","packet_loss","availability"],
}

asset_rows = []
for i in range(1, C["assets"] + 1):
    store_id = f"S{random.randint(1, C['stores']):04d}"
    category, asset_type = random.choice(asset_types)
    asset_rows.append((
        f"A{i:07d}", store_id, category, asset_type,
        random.choice(["Carrier","Trane","Danfoss","Emerson","Honeywell","Johnson Controls"]),
        f"MODEL-{random.randint(100,999)}",
        datetime(2020,1,1) + timedelta(days=random.randint(0,2300)),
        random.choice(["Active","Active","Active","Maintenance"])
    ))

assets = spark.createDataFrame(asset_rows,
    "asset_id string, store_id string, asset_category string, asset_type string, "
    "manufacturer string, model string, install_date timestamp, asset_status string"
)
assets.write.mode("overwrite").format("parquet").save(f"{OUT}/assets")

# -------------------------
# Devices/sensors dimension
# -------------------------
sensor_rows = []
for i in range(1, C["sensors"] + 1):
    asset = asset_rows[random.randint(0, len(asset_rows)-1)]
    asset_id, store_id, _, asset_type = asset[:4]
    sensor_type = random.choice(asset_sensor_types[asset_type])
    sensor_rows.append((
        f"D{i:07d}", asset_id, store_id, sensor_type,
        random.choice(["v3.1","v3.2","v4.0","v4.1"]),
        random.choice(["WiFi","Ethernet","5G","LoRaWAN"]),
        random.choice(["Online","Online","Online","Intermittent"])
    ))

sensors = spark.createDataFrame(sensor_rows,
    "device_id string, asset_id string, store_id string, sensor_type string, "
    "firmware_version string, connectivity_type string, device_status string"
)
sensors.write.mode("overwrite").format("parquet").save(f"{OUT}/devices")

# -------------------------
# Maintenance events
# -------------------------
maintenance_rows = []
for i in range(1, max(C["assets"] // 2, 1000) + 1):
    asset_id, store_id, _, asset_type = random.choice(asset_rows)[:4]
    maintenance_rows.append((
        f"M{i:08d}", asset_id, store_id,
        datetime(2026,1,1) + timedelta(days=random.randint(0,250)),
        random.choice(["Preventive","Corrective","Inspection"]),
        random.choice(["Completed","Completed","Scheduled","Open"]),
        random.choice(["Sensor calibration","Compressor service","Firmware update",
                       "HVAC inspection","Network repair","Routine maintenance"]),
        random.randint(100, 2500)
    ))

maintenance = spark.createDataFrame(maintenance_rows,
    "maintenance_id string, asset_id string, store_id string, maintenance_ts timestamp, "
    "maintenance_type string, maintenance_status string, maintenance_reason string, "
    "maintenance_cost double"
)
maintenance.write.mode("overwrite").format("parquet").save(f"{OUT}/maintenance")

# -------------------------
# Telemetry (IoT sensor readings)
# -------------------------
intervals = int(C["days"] * 24 * 60 / C["telemetry_minutes"])

devices_small = sensors.select("device_id","asset_id","store_id","sensor_type","firmware_version")

times = spark.range(intervals).select(
    (F.expr(f"timestamp('{start.isoformat()}')") +
    (F.col("id") * F.expr(f"INTERVAL {C['telemetry_minutes']} MINUTES"))).alias("event_time")
)

telemetry = devices_small.crossJoin(times)

telemetry = (
    telemetry
    .withColumn("event_id", F.sha2(F.concat_ws("|","device_id","event_time"),256))
    .withColumn("ingestion_delay_sec",
                F.when(F.rand(7) < 0.015, F.expr("cast(rand(8)*1800 as int)"))
                 .otherwise(F.expr("cast(rand(9)*30 as int)")))
    .withColumn("event_time_actual", F.col("event_time"))
    .withColumn("ingestion_time",
                F.col("event_time") + F.expr("make_interval(0,0,0,0,0,0,ingestion_delay_sec)"))
)

telemetry = (
    telemetry
    .withColumn(
        "value",
        F.when(F.col("sensor_type")=="temperature",
               F.round(35 + F.rand(11)*10 + F.sin(F.hour("event_time")/24*6.28)*2,2))
        .when(F.col("sensor_type")=="humidity",
              F.round(45 + F.rand(12)*25,2))
        .when(F.col("sensor_type")=="compressor_state",
              F.when(F.rand(13)<0.45, F.lit(1.0)).otherwise(F.lit(0.0)))
        .when(F.col("sensor_type")=="power_kw",
              F.round(2 + F.rand(14)*18,2))
        .when(F.col("sensor_type")=="voltage",
              F.round(115 + F.rand(15)*10,2))
        .when(F.col("sensor_type")=="latency_ms",
              F.round(20 + F.rand(16)*80,2))
        .when(F.col("sensor_type")=="error_rate",
              F.round(F.rand(17)*2,4))
        .when(F.col("sensor_type")=="availability",
              F.when(F.rand(18)<0.98,1.0).otherwise(0.0))
        .when(F.col("sensor_type")=="stock_level",
              F.round(F.rand(19)*100,0))
        .when(F.col("sensor_type")=="weight_kg",
              F.round(F.rand(20)*50,2))
        .when(F.col("sensor_type")=="door_open",
              F.when(F.rand(21)<0.08,1.0).otherwise(0.0))
        .when(F.col("sensor_type")=="fan_speed",
              F.round(F.rand(22)*100,1))
        .when(F.col("sensor_type")=="read_rate",
              F.round(85 + F.rand(23)*15,2))
        .when(F.col("sensor_type")=="packet_loss",
              F.round(F.rand(24)*3,3))
        .otherwise(F.rand(25))
    )
    .withColumn(
        "unit",
        F.when(F.col("sensor_type")=="temperature","F")
         .when(F.col("sensor_type")=="humidity","pct")
         .when(F.col("sensor_type")=="power_kw","kW")
         .when(F.col("sensor_type")=="voltage","V")
         .when(F.col("sensor_type")=="latency_ms","ms")
         .when(F.col("sensor_type")=="error_rate","pct")
         .when(F.col("sensor_type")=="availability","boolean")
         .otherwise("unit")
    )
    .withColumn("quality_seed", F.rand(99))
)

# Inject realistic defects into the telemetry.
# 1. Impossible temperatures
telemetry = telemetry.withColumn(
    "value",
    F.when((F.col("sensor_type")=="temperature") & (F.col("quality_seed")<0.0008), F.lit(999.0))
     .when((F.col("sensor_type")=="temperature") & (F.col("quality_seed").between(0.0008,0.0015)), F.lit(-99.0))
     .otherwise(F.col("value"))
)

# 2. Null values
telemetry = telemetry.withColumn(
    "value",
    F.when(F.col("quality_seed").between(0.002,0.003), F.lit(None).cast("double"))
     .otherwise(F.col("value"))
)

# 3. Duplicate events
dupes = telemetry.filter(F.col("quality_seed") < 0.0007).withColumn(
    "event_id", F.concat(F.col("event_id"), F.lit("_DUP"))
)
telemetry = telemetry.unionByName(dupes)

# 4. Firmware-related anomaly: selected devices have elevated refrigeration temperatures
bad_devices = sensors.filter(
    (F.col("sensor_type")=="temperature") &
    (F.col("device_id").substr(-2,2).cast("int").between(40,49))
).select("device_id").withColumn("bad_device", F.lit(1))

telemetry = telemetry.join(F.broadcast(bad_devices), "device_id", "left")

telemetry = telemetry.withColumn(
    "value",
    F.when(
        (F.col("sensor_type")=="temperature") &
        (F.col("bad_device")==1) &
        (F.col("event_time") >= F.lit(start + timedelta(days=4))) &
        (F.col("event_time") < F.lit(start + timedelta(days=6))),
        F.col("value") + 8
    ).otherwise(F.col("value"))
)

telemetry = telemetry.drop("bad_device","quality_seed")

telemetry = telemetry.select(
    "event_id","device_id","asset_id","store_id","sensor_type",
    "firmware_version","event_time","ingestion_time",
    "value","unit"
)

telemetry.write.mode("overwrite").format("parquet").save(f"{OUT}/telemetry")

print("V2 data generation complete (business + IoT).")