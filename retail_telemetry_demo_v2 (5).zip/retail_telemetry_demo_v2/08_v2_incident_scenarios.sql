-- Controlled scenarios for a live demo.
-- Run, refresh derived tables, and then use Genie.

-- Scenario 1: Store 0042 refrigeration excursion (day 5 of data window)
-- Data starts at current_date() - 7 days; day 5 = current_date() - 2 days
UPDATE retail_demo.silver.fact_telemetry
SET value = 52
WHERE store_id='S0042'
  AND sensor_type='temperature'
  AND event_time >= TIMESTAMP(DATEADD(day, -2, CURRENT_DATE())) + INTERVAL 10 HOURS
  AND event_time <  TIMESTAMP(DATEADD(day, -2, CURRENT_DATE())) + INTERVAL 12 HOURS;

-- Scenario 2: Store 0042 late telemetry (same window)
UPDATE retail_demo.silver.fact_telemetry
SET ingestion_time = event_time + INTERVAL 30 MINUTES
WHERE store_id='S0042'
  AND event_time >= TIMESTAMP(DATEADD(day, -2, CURRENT_DATE())) + INTERVAL 10 HOURS
  AND event_time <  TIMESTAMP(DATEADD(day, -2, CURRENT_DATE())) + INTERVAL 12 HOURS;

-- Scenario 3: energy spike is already injected for S0018/S0042/S0077
-- in 01_v2_generate_business_data.py.

-- Rebuild:
-- 03_v2_quality_and_risk.sql
-- 04_v2_genie_views.sql
