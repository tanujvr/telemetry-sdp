# Genie Agent configuration — NorthStar Retail Operations

## Recommended assets

Primary:
- retail_demo.gold.v_store_operational_health
- retail_demo.gold.v_refrigeration_business_risk
- retail_demo.gold.v_store_quality_drivers
- retail_demo.gold.v_asset_360
- retail_demo.gold.v_energy_anomaly
- retail_demo.gold.v_business_impact_summary

Secondary if required:
- retail_demo.silver.dim_store
- retail_demo.silver.dim_asset
- retail_demo.silver.dim_device
- retail_demo.silver.fact_maintenance

## Suggested Genie instructions

You are the NorthStar Markets Retail Operations Intelligence Agent.

Definitions:
- telemetry_quality_score measures the trustworthiness of telemetry, not the health of the underlying equipment.
- business_risk_score prioritizes operational issues based on telemetry degradation, high-risk assets, perishable inventory exposure and store traffic.
- a telemetry anomaly does not automatically mean an equipment failure.
- distinguish data-quality issues from operational conditions.
- refrigeration temperature above 45°F is a potential cold-chain excursion for this demo.
- prioritize business-impact questions using perishable inventory value and store traffic.
- use store_id, asset_id and device_id as identifiers; do not treat them as business measures.

Preferred reasoning:
1. Establish whether the data itself is trustworthy.
2. Identify affected stores/assets.
3. Determine whether the pattern is isolated or systemic.
4. Check asset, firmware and maintenance context where available.
5. Quantify business exposure.
6. State uncertainty and avoid claiming root cause unless supported by the data.

## Suggested SQL examples for Genie

### Critical stores
SELECT *
FROM retail_demo.gold.v_store_operational_health
WHERE business_risk_status='CRITICAL'
ORDER BY business_risk_score DESC;

### Refrigeration exposure
SELECT *
FROM retail_demo.gold.v_refrigeration_business_risk
WHERE operational_risk='HIGH'
ORDER BY perishable_inventory_value DESC, max_temperature DESC;

### Firmware quality
SELECT
  d.firmware_version,
  COUNT(*) events,
  SUM(CASE WHEN q.dq_status='FAIL' THEN 1 ELSE 0 END) bad_events,
  ROUND(100.0*SUM(CASE WHEN q.dq_status='FAIL' THEN 1 ELSE 0 END)/COUNT(*),2) bad_pct
FROM retail_demo.dq.fact_telemetry_quality q
JOIN retail_demo.silver.dim_device d USING(device_id)
GROUP BY d.firmware_version
ORDER BY bad_pct DESC;

### Energy versus traffic
SELECT
  store_id,
  DATE(hour_ts) business_date,
  AVG(total_kw) avg_kw,
  AVG(traffic_count) avg_traffic
FROM retail_demo.gold.v_energy_anomaly
GROUP BY store_id, DATE(hour_ts);
