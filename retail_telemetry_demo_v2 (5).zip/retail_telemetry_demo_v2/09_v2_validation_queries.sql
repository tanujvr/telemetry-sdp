-- Validation / demo health checks

-- Row counts
SELECT 'stores' object, COUNT(*) rows FROM retail_demo.silver.dim_store
UNION ALL SELECT 'assets', COUNT(*) FROM retail_demo.silver.dim_asset
UNION ALL SELECT 'devices', COUNT(*) FROM retail_demo.silver.dim_device
UNION ALL SELECT 'products', COUNT(*) FROM retail_demo.silver.dim_product
UNION ALL SELECT 'telemetry', COUNT(*) FROM retail_demo.silver.fact_telemetry
UNION ALL SELECT 'sales', COUNT(*) FROM retail_demo.silver.fact_sales
UNION ALL SELECT 'inventory', COUNT(*) FROM retail_demo.silver.fact_inventory_snapshot
UNION ALL SELECT 'traffic', COUNT(*) FROM retail_demo.silver.fact_store_traffic
UNION ALL SELECT 'energy', COUNT(*) FROM retail_demo.silver.fact_energy;

-- Highest business-risk stores
SELECT *
FROM retail_demo.gold.v_store_operational_health
ORDER BY business_risk_score DESC
LIMIT 20;

-- Highest refrigeration risk
SELECT *
FROM retail_demo.gold.v_refrigeration_business_risk
ORDER BY
  CASE operational_risk WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END,
  perishable_inventory_value DESC
LIMIT 20;

-- Energy anomaly
SELECT *
FROM retail_demo.gold.v_energy_anomaly
WHERE energy_anomaly_flag=true
ORDER BY total_kw DESC;

-- Quality by firmware
SELECT
  d.firmware_version,
  COUNT(*) events,
  SUM(CASE WHEN q.dq_status='FAIL' THEN 1 ELSE 0 END) bad_events,
  ROUND(100.0*SUM(CASE WHEN q.dq_status='FAIL' THEN 1 ELSE 0 END)/COUNT(*),2) bad_pct
FROM retail_demo.dq.fact_telemetry_quality q
JOIN retail_demo.silver.dim_device d USING(device_id)
GROUP BY d.firmware_version
ORDER BY bad_pct DESC;
