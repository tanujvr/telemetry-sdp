-- ============================================================
-- TELEMETRY QUALITY
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.dq.fact_telemetry_quality AS
SELECT
  t.*,
  CASE
    WHEN event_id IS NULL THEN 'FAIL'
    WHEN device_id IS NULL OR asset_id IS NULL OR store_id IS NULL THEN 'FAIL'
    WHEN event_time IS NULL OR event_time > current_timestamp() THEN 'FAIL'
    WHEN value IS NULL THEN 'FAIL'
    WHEN sensor_type='temperature' AND (value < -40 OR value > 150) THEN 'FAIL'
    WHEN sensor_type='humidity' AND (value < 0 OR value > 100) THEN 'FAIL'
    WHEN sensor_type='availability' AND value NOT IN (0,1) THEN 'FAIL'
    WHEN ingestion_time < event_time THEN 'FAIL'
    WHEN unix_timestamp(ingestion_time)-unix_timestamp(event_time) > 900 THEN 'LATE'
    ELSE 'PASS'
  END AS dq_status,

  CASE
    WHEN value IS NULL THEN 'COMPLETENESS'
    WHEN sensor_type='temperature' AND (value < -40 OR value > 150) THEN 'VALIDITY'
    WHEN sensor_type='humidity' AND (value < 0 OR value > 100) THEN 'VALIDITY'
    WHEN unix_timestamp(ingestion_time)-unix_timestamp(event_time) > 900 THEN 'TIMELINESS'
    ELSE 'NONE'
  END AS dq_dimension

-- Read from the SDP quality-controlled table (output of 05_v2_dq_lakeflow_nb)
FROM retail_demo.silver.silver_telemetry_quality_controlled t;


-- ============================================================
-- STORE-LEVEL QUALITY
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.dq.fact_data_quality_daily AS
WITH base AS (
  SELECT
    store_id,
    CAST(event_time AS DATE) AS quality_date,
    COUNT(*) AS events,
    COUNT(DISTINCT device_id) AS reporting_devices,
    SUM(CASE WHEN dq_status='PASS' THEN 1 ELSE 0 END) AS valid_events,
    SUM(CASE WHEN dq_status='FAIL' THEN 1 ELSE 0 END) AS invalid_events,
    SUM(CASE WHEN dq_status='LATE' THEN 1 ELSE 0 END) AS late_events
  FROM retail_demo.dq.fact_telemetry_quality
  GROUP BY store_id, CAST(event_time AS DATE)
),
expected AS (
  SELECT store_id, COUNT(DISTINCT device_id) AS expected_devices
  FROM retail_demo.silver.dim_device
  GROUP BY store_id
)
SELECT
  b.*,
  e.expected_devices,
  ROUND(100*b.valid_events/NULLIF(b.events,0),2) AS validity_pct,
  ROUND(100*(b.events-b.late_events)/NULLIF(b.events,0),2) AS timeliness_pct,
  ROUND(100*b.reporting_devices/NULLIF(e.expected_devices,0),2) AS device_coverage_pct,
  ROUND(
    0.35*(100*b.valid_events/NULLIF(b.events,0)) +
    0.30*(100*(b.events-b.late_events)/NULLIF(b.events,0)) +
    0.35*(100*b.reporting_devices/NULLIF(e.expected_devices,0))
  ,2) AS telemetry_quality_score
FROM base b
JOIN expected e USING(store_id);


-- ============================================================
-- ASSET OPERATIONAL RISK
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.gold.fact_asset_operational_risk AS
WITH telemetry AS (
  SELECT
    asset_id,
    store_id,
    sensor_type,
    COUNT(*) AS events,
    SUM(CASE WHEN dq_status='FAIL' THEN 1 ELSE 0 END) AS bad_events,
    AVG(CASE WHEN sensor_type='temperature' THEN value END) AS avg_temperature,
    MAX(CASE WHEN sensor_type='temperature' THEN value END) AS max_temperature,
    SUM(CASE WHEN sensor_type='temperature' AND value > 45 THEN 1 ELSE 0 END) AS warm_events
  FROM retail_demo.dq.fact_telemetry_quality
  GROUP BY asset_id, store_id, sensor_type
),
maint AS (
  SELECT asset_id, COUNT(*) AS maintenance_events, SUM(maintenance_cost) AS maintenance_cost
  FROM retail_demo.silver.fact_maintenance
  GROUP BY asset_id
)
SELECT
  a.asset_id,
  a.store_id,
  a.asset_category,
  a.asset_type,
  a.manufacturer,
  a.model,
  SUM(t.events) AS telemetry_events,
  SUM(t.bad_events) AS bad_events,
  ROUND(100*SUM(t.bad_events)/NULLIF(SUM(t.events),0),2) AS bad_event_pct,
  ROUND(AVG(t.avg_temperature),2) AS avg_temperature,
  ROUND(MAX(t.max_temperature),2) AS max_temperature,
  SUM(t.warm_events) AS warm_temperature_events,
  COALESCE(m.maintenance_events,0) AS maintenance_events,
  COALESCE(m.maintenance_cost,0) AS maintenance_cost,
  CASE
    WHEN a.asset_category='REFRIGERATION' AND MAX(t.max_temperature)>45 THEN 'HIGH'
    WHEN SUM(t.bad_events)>20 THEN 'HIGH'
    WHEN COALESCE(m.maintenance_events,0)>=3 THEN 'MEDIUM'
    ELSE 'LOW'
  END AS operational_risk
FROM retail_demo.silver.dim_asset a
LEFT JOIN telemetry t USING(asset_id,store_id)
LEFT JOIN maint m USING(asset_id)
GROUP BY
  a.asset_id,a.store_id,a.asset_category,a.asset_type,
  a.manufacturer,a.model,m.maintenance_events,m.maintenance_cost;


-- ============================================================
-- BUSINESS EXPOSURE
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.gold.fact_store_business_exposure AS
WITH inventory AS (
  SELECT
    store_id,
    SUM(inventory_value) AS inventory_value,
    SUM(CASE WHEN perishable_exposure_flag THEN inventory_value ELSE 0 END) AS perishable_inventory_value,
    SUM(CASE WHEN oos_flag THEN 1 ELSE 0 END) AS oos_product_count
  FROM retail_demo.silver.fact_inventory_snapshot
  GROUP BY store_id
),
sales AS (
  SELECT
    store_id,
    SUM(net_sales) AS net_sales,
    SUM(gross_margin) AS gross_margin
  FROM retail_demo.silver.fact_sales
  GROUP BY store_id
),
traffic AS (
  SELECT
    store_id,
    SUM(traffic_count) AS traffic,
    AVG(peak_queue_minutes) AS avg_queue_minutes
  FROM retail_demo.silver.fact_store_traffic
  GROUP BY store_id
)
SELECT
  s.store_id,
  s.store_name,
  COALESCE(i.inventory_value,0) AS inventory_value,
  COALESCE(i.perishable_inventory_value,0) AS perishable_inventory_value,
  COALESCE(i.oos_product_count,0) AS oos_product_count,
  COALESCE(sa.net_sales,0) AS net_sales,
  COALESCE(sa.gross_margin,0) AS gross_margin,
  COALESCE(tr.traffic,0) AS traffic,
  ROUND(COALESCE(tr.avg_queue_minutes,0),2) AS avg_queue_minutes
FROM retail_demo.silver.dim_store s
LEFT JOIN inventory i USING(store_id)
LEFT JOIN sales sa USING(store_id)
LEFT JOIN traffic tr USING(store_id);


-- ============================================================
-- COMBINED STORE OPERATIONAL RISK
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.gold.fact_store_operational_risk AS
WITH quality AS (
  SELECT
    store_id,
    AVG(telemetry_quality_score) AS quality_score,
    AVG(device_coverage_pct) AS device_coverage_pct
  FROM retail_demo.dq.fact_data_quality_daily
  GROUP BY store_id
),
asset AS (
  SELECT
    store_id,
    SUM(CASE WHEN operational_risk='HIGH' THEN 1 ELSE 0 END) AS high_risk_assets,
    SUM(warm_temperature_events) AS warm_events
  FROM retail_demo.gold.fact_asset_operational_risk
  GROUP BY store_id
),
exposure AS (
  SELECT * FROM retail_demo.gold.fact_store_business_exposure
)
SELECT
  e.*,
  ROUND(COALESCE(q.quality_score,100),2) AS telemetry_quality_score,
  ROUND(COALESCE(q.device_coverage_pct,100),2) AS device_coverage_pct,
  COALESCE(a.high_risk_assets,0) AS high_risk_assets,
  COALESCE(a.warm_events,0) AS warm_events,

  ROUND(
    (
      (100-COALESCE(q.quality_score,100))*0.20 +
      LEAST(COALESCE(a.high_risk_assets,0)*5,30)*0.30 +
      LEAST(COALESCE(e.perishable_inventory_value,0)/10000,30)*0.30 +
      LEAST(COALESCE(e.traffic,0)/10000,20)*0.20
    ),2
  ) AS business_risk_score,

  CASE
    WHEN (
      (100-COALESCE(q.quality_score,100))*0.20 +
      LEAST(COALESCE(a.high_risk_assets,0)*5,30)*0.30 +
      LEAST(COALESCE(e.perishable_inventory_value,0)/10000,30)*0.30 +
      LEAST(COALESCE(e.traffic,0)/10000,20)*0.20
    ) >= 50 THEN 'CRITICAL'
    WHEN (
      (100-COALESCE(q.quality_score,100))*0.20 +
      LEAST(COALESCE(a.high_risk_assets,0)*5,30)*0.30 +
      LEAST(COALESCE(e.perishable_inventory_value,0)/10000,30)*0.30 +
      LEAST(COALESCE(e.traffic,0)/10000,20)*0.20
    ) >= 25 THEN 'HIGH'
    ELSE 'NORMAL'
  END AS business_risk_status

FROM exposure e
LEFT JOIN quality q USING(store_id)
LEFT JOIN asset a USING(store_id);


-- ============================================================
-- HOURLY TEMPERATURE AGGREGATION (for ai_forecast input)
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.dq.fact_hourly_temps AS
SELECT
  asset_id,
  store_id,
  DATE_TRUNC('hour', event_time) AS hour_ts,
  AVG(value) AS avg_temp,
  MIN(value) AS min_temp,
  MAX(value) AS max_temp,
  COUNT(*) AS event_count
FROM retail_demo.dq.fact_telemetry_quality
WHERE sensor_type = 'temperature'
GROUP BY asset_id, store_id, DATE_TRUNC('hour', event_time);


-- ============================================================
-- AI FORECAST — Predict temperature for HIGH-risk assets
-- ============================================================

CREATE OR REPLACE TABLE retail_demo.gold.asset_failure_forecast AS
SELECT * FROM ai_forecast(
  TABLE(
    SELECT h.asset_id, h.hour_ts, h.avg_temp
    FROM retail_demo.dq.fact_hourly_temps h
    JOIN retail_demo.gold.fact_asset_operational_risk r USING(asset_id)
    WHERE r.operational_risk = 'HIGH'
      AND h.hour_ts >= (SELECT MAX(hour_ts) - INTERVAL 7 DAYS FROM retail_demo.dq.fact_hourly_temps)
  ),
  horizon => (SELECT MAX(hour_ts) + INTERVAL 24 HOURS FROM retail_demo.dq.fact_hourly_temps),
  time_col => 'hour_ts',
  value_col => 'avg_temp',
  group_col => 'asset_id',
  version => '1'
);
