-- Keep the Genie surface intentionally small and business-oriented.

CREATE OR REPLACE VIEW retail_demo.gold.v_store_operational_health AS
SELECT
  r.store_id,
  r.store_name,
  s.store_type,
  s.region,
  s.state_code,
  r.telemetry_quality_score,
  r.device_coverage_pct,
  r.high_risk_assets,
  r.warm_events,
  r.inventory_value,
  r.perishable_inventory_value,
  r.oos_product_count,
  r.net_sales,
  r.gross_margin,
  r.traffic,
  r.avg_queue_minutes,
  r.business_risk_score,
  r.business_risk_status
FROM retail_demo.gold.fact_store_operational_risk r
JOIN retail_demo.silver.dim_store s USING(store_id);


CREATE OR REPLACE VIEW retail_demo.gold.v_refrigeration_business_risk AS
SELECT
  a.asset_id,
  a.store_id,
  s.store_name,
  s.region,
  a.asset_type,
  a.manufacturer,
  a.model,
  a.bad_event_pct,
  a.avg_temperature,
  a.max_temperature,
  a.warm_temperature_events,
  a.maintenance_events,
  a.maintenance_cost,
  a.operational_risk,
  r.perishable_inventory_value,
  r.traffic,
  r.net_sales
FROM retail_demo.gold.fact_asset_operational_risk a
JOIN retail_demo.gold.fact_store_business_exposure r USING(store_id)
JOIN retail_demo.silver.dim_store s USING(store_id)
WHERE a.asset_category='REFRIGERATION';


CREATE OR REPLACE VIEW retail_demo.gold.v_store_quality_drivers AS
SELECT
  q.store_id,
  s.store_name,
  s.region,
  q.quality_date,
  q.events,
  q.reporting_devices,
  q.expected_devices,
  q.validity_pct,
  q.timeliness_pct,
  q.device_coverage_pct,
  q.telemetry_quality_score
FROM retail_demo.dq.fact_data_quality_daily q
JOIN retail_demo.silver.dim_store s USING(store_id);


CREATE OR REPLACE VIEW retail_demo.gold.v_asset_360 AS
SELECT
  a.asset_id,
  a.store_id,
  s.store_name,
  s.region,
  a.asset_category,
  a.asset_type,
  a.manufacturer,
  a.model,
  a.bad_event_pct,
  a.avg_temperature,
  a.max_temperature,
  a.warm_temperature_events,
  a.maintenance_events,
  a.maintenance_cost,
  a.operational_risk
FROM retail_demo.gold.fact_asset_operational_risk a
JOIN retail_demo.silver.dim_store s USING(store_id);


CREATE OR REPLACE VIEW retail_demo.gold.v_energy_anomaly AS
SELECT
  e.store_id,
  s.store_name,
  s.region,
  e.hour_ts,
  e.hvac_kw,
  e.refrigeration_kw,
  e.lighting_kw,
  e.total_kw,
  e.energy_kwh,
  e.energy_anomaly_flag,
  t.traffic_count,
  t.peak_queue_minutes
FROM retail_demo.silver.fact_energy e
JOIN retail_demo.silver.dim_store s USING(store_id)
LEFT JOIN retail_demo.silver.fact_store_traffic t
  ON e.store_id=t.store_id AND e.hour_ts=t.hour_ts;


CREATE OR REPLACE VIEW retail_demo.gold.v_business_impact_summary AS
SELECT
  store_id,
  store_name,
  telemetry_quality_score,
  business_risk_score,
  business_risk_status,
  high_risk_assets,
  perishable_inventory_value,
  inventory_value,
  net_sales,
  traffic,
  avg_queue_minutes,
  oos_product_count
FROM retail_demo.gold.fact_store_operational_risk;


-- ============================================================
-- PREDICTIVE MAINTENANCE (ai_forecast-powered)
-- ============================================================

CREATE OR REPLACE VIEW retail_demo.gold.v_predictive_maintenance AS
SELECT
  f.asset_id,
  lk.store_id,
  s.store_name,
  s.region,
  a.asset_category,
  a.asset_type,
  a.manufacturer,
  a.model,
  r.operational_risk AS current_risk,
  f.hour_ts AS forecast_hour,
  f.avg_temp_forecast AS predicted_temp,
  f.avg_temp_lower AS predicted_temp_lower,
  f.avg_temp_upper AS predicted_temp_upper,
  e.perishable_inventory_value,
  e.net_sales,
  CASE
    WHEN f.avg_temp_forecast > 50 THEN 'CRITICAL - Schedule emergency maintenance'
    WHEN f.avg_temp_forecast > 45 THEN 'WARNING - Monitor closely'
    ELSE 'NORMAL'
  END AS predictive_alert
FROM retail_demo.gold.asset_failure_forecast f
JOIN (SELECT DISTINCT asset_id, store_id FROM retail_demo.dq.fact_hourly_temps) lk USING(asset_id)
JOIN retail_demo.silver.dim_store s USING(store_id)
JOIN retail_demo.silver.dim_asset a USING(asset_id, store_id)
JOIN retail_demo.gold.fact_asset_operational_risk r USING(asset_id, store_id)
JOIN retail_demo.gold.fact_store_business_exposure e USING(store_id);
