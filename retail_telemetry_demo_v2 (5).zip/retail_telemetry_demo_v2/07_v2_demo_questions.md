# 15-minute customer demo script

## Opening

"NorthStar Markets operates 500 stores with thousands of connected assets per store.
The question is not whether the retailer has telemetry. It is whether the retailer can trust
the signals enough to act on them."

## Act 1 — Data trust

1. Which stores have the poorest telemetry quality?
2. What are the main drivers of poor quality?
3. Is the problem completeness, validity, timeliness or device coverage?
4. Is the issue concentrated by firmware version or connectivity type?

## Act 2 — Operational signal

5. Which refrigeration assets show signs of a genuine temperature excursion?
6. Is Store 0042's problem likely a data-quality issue or an actual refrigeration issue?
7. Which assets have recurring problems and maintenance history?

## Act 3 — Business context

8. Which high-risk refrigeration assets are associated with the largest perishable inventory exposure?
9. Which affected stores also have high customer traffic?
10. Which five issues should Facilities investigate first?

## Act 4 — Energy

11. Which stores have abnormal energy consumption?
12. Are the energy anomalies explained by higher store traffic?
13. Which stores have high refrigeration energy and refrigeration telemetry risk at the same time?

## Act 5 — Executive

14. Give me the top five operational risks and explain why each is important.
15. Summarize today's retail telemetry health in five bullets for the COO.

## Expected story

A strong answer should progressively move from:
DATA TRUST
to
OPERATIONAL CONDITION
to
BUSINESS EXPOSURE
to
PRIORITY.

The demo should explicitly avoid claiming that telemetry quality alone proves equipment failure.
