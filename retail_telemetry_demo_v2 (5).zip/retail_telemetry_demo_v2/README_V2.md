# NorthStar Markets — Retail Telemetry DQ + Genie Demo V2

Version 2 extends the telemetry demo into a formal retail star schema and adds:
- Sales
- Inventory
- Store traffic
- Energy
- Maintenance
- Operational risk / business exposure

## Recommended demo scale

Demo:
- 100 stores
- 10,000 assets
- 5,000 devices
- 7 days of 5-minute telemetry
- 2,500 products
- Hourly sales / traffic / energy
- Daily inventory snapshots

Scale:
- 500 stores
- 75,000 assets
- 30,000 devices
- 14 days of 5-minute telemetry
- 10,000 products
- Hourly sales / traffic / energy
- Daily inventory snapshots

## Star schema

### Dimensions
dim_date
dim_time
dim_store
dim_department
dim_product
dim_asset
dim_device
dim_firmware

### Facts
fact_sales
fact_inventory_snapshot
fact_store_traffic
fact_energy
fact_telemetry
fact_maintenance

### Quality / derived facts
fact_telemetry_quality
fact_data_quality_daily
fact_asset_operational_risk
fact_store_operational_risk

### Genie-ready semantic views
v_store_operational_health
v_refrigeration_business_risk
v_store_quality_drivers
v_asset_360
v_energy_anomaly
v_business_impact_summary

## Key business relationships

Telemetry -> Asset -> Store
Inventory -> Product -> Department -> Store
Sales -> Product -> Department -> Store
Traffic -> Store
Energy -> Store
Maintenance -> Asset -> Store

## Demo narrative

1. Find stores with poor telemetry quality.
2. Separate data-quality problems from real operational problems.
3. Prioritize real problems using inventory, sales and traffic exposure.
4. Explain the likely root cause using asset, device, firmware and maintenance context.
5. Compare energy anomalies against store traffic and operating conditions.
6. Ask Genie for an executive summary.

The central metric is not simply DQ score. It is:
DATA TRUST + OPERATIONAL RISK + BUSINESS EXPOSURE = PRIORITY.
